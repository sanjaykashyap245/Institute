create database Institute;
 
 use Institute;

 Create table Institute
 (
 InstituteId int identity(1000,1) primary key,
 InstituteName varchar(50),
 City varchar(50)
 );

 
 Create table Course
 (
 CourseId int identity(100,1) primary key,
 CourseName varchar(50)
 );

 
 Create table Student
 (
 StudentId int identity(1,1) primary key,
 StudentName varchar(50),
 DOB datetime
 );

 
 Create table Admission
 (
 AdmissionId int identity(10,1) primary key,
 AdmissionDate datetime,
 StudentId int foreign key references Student(StudentId),
 CourseId int foreign key references Course(CourseId),
 InstituteId int foreign key references Institute(InstituteId)
);

go
Create procedure addStudent
(@studentname varchar(50),
@dob datetime,
@city varchar(50),
@institutename varchar(50),
@coursename varchar(50),
@admdate datetime
)
AS
Begin
Insert into Admission values(@admdate,
							 (Select StudentId from student
							 where StudentName=@studentname),
							 (Select CourseId from Course
							 where CourseName=@coursename),
							(Select InstituteId from Institute
							 where InstituteName=@institutename))
End

go
create procedure GetallCourse
AS
Select * from Course;

go
create procedure GetAllInstitute
As
Select * from Institute;

--go 
--create procedure GetAllAdmissions
--(
--@admissionid int,
--@admissiondate datetime,
--@studentname int,
--@courseid int,
--@instituteid int
--)
--AS
--Begin
--Declare @studentid 