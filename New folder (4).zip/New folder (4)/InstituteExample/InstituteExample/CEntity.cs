﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InstituteExample
{
    public class CEntity
    {
        public string StudentName { get; set; }
        public DateTime DOB { get; set; }
        public string City { get; set; }
        public string InstituteName { get; set; }
        public string CourseName { get; set; }
        public DateTime AdmissionDate { get; set; }
    }
}