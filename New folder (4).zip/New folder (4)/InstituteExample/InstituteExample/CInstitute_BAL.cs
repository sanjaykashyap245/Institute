﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InstituteExample
{
    public class CInstitute_BAL
    {
        internal bool authenticateUser(string txtusername, string txtPasswd)
        {
            CInstitute_DAL dalObj = new CInstitute_DAL();
            return dalObj.authenticateUser(txtusername, txtPasswd);

        }
        internal bool addStudent(CEntity newregistration)
        {
            CInstitute_DAL dalObj = new CInstitute_DAL();
            return dalObj.addStudent(newregistration);
        }
        public static List<string> mGetAllCourse()
        {
            CInstitute_DAL dalObj = new CInstitute_DAL();
            return dalObj.mGetallCourse();
        }
        public static List<string> mGetAllInstitute()
        {
            CInstitute_DAL dalObj = new CInstitute_DAL();
            return dalObj.mGetAllInstitute();
        }
    }
}