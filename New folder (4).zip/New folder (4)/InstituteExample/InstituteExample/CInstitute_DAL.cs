﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace InstituteExample
{
    public class CInstitute_DAL
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=Institute;Integrated Security=True");
        SqlCommand com;
        internal bool authenticateUser(string txtusername, string txtPasswd)
        {
            if (txtusername.Equals("sanju") && txtPasswd.Equals("password"))
                return true;
            else
                return false;
        }
        internal bool addStudent(CEntity newregistration)
        {

            try
            {
                con.Open();
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);

            }
            com = new SqlCommand();
            com.Connection = con;
            com.CommandType = CommandType.StoredProcedure;
            com.CommandText = "addStudent";

            SqlParameter param = new SqlParameter();
            param.ParameterName = "@studentName";
            param.DbType = DbType.String;
            param.Value = newregistration.StudentName;
            com.Parameters.Add(param);

            param = new SqlParameter();
            param.ParameterName = "@dob";
            param.DbType = DbType.String;
            param.Value = newregistration.DOB.ToString();
            com.Parameters.Add(param);

            param.ParameterName = "@city";
            param.DbType = DbType.String;
            param.Value = newregistration.City;
            com.Parameters.Add(param);
            
            param.ParameterName = "@institutename";
            param.DbType = DbType.String;
            param.Value = newregistration.InstituteName;
            com.Parameters.Add(param);

            param.ParameterName = "@coursename";
            param.DbType = DbType.String;
            param.Value = newregistration.CourseName;
            com.Parameters.Add(param);

            param.ParameterName = "@admdate";
            param.DbType = DbType.String;
            param.Value = newregistration.AdmissionDate.ToString();
            com.Parameters.Add(param);

            int affectedrows = com.ExecuteNonQuery();
            if (affectedrows > 0)
                return true;
            else
                return false;
        }
        public List<string> mGetallCourse()
        {
            List<string> list = new List<string>();
            try
            {
                con.Open();
                com = new SqlCommand("GetAllCourse", con);
                com.CommandType = CommandType.StoredProcedure;
                SqlDataReader obj = com.ExecuteReader();
                while (obj.HasRows)
                {
                    while (obj.Read())
                    {
                        list.Add(obj[0].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            con.Close();
            return list;
        }
        public List<string> mGetAllInstitute()
        {
            List<string> list = new List<string>();
            try
            {
                con.Open();
                com = new SqlCommand("GetAllInstitute", con);
                com.CommandType = CommandType.StoredProcedure;
                SqlDataReader obj = com.ExecuteReader();
                while (obj.HasRows)
                {
                    while (obj.Read())
                    {
                        list.Add(obj[0].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            con.Close();
            return list;
        }
    }
}