﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InstituteExample
{
    public partial class InstituteLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            CInstitute_BAL bobj = new CInstitute_BAL();
            if (bobj.authenticateUser(txtusername.Text, txtpwd.Text))
            {
                Response.Redirect("InstituteRegistration.aspx");
                //FormsAuthentication.RedirectFromLoginPage(txtusername.Text, false);
            }
            else
            {
                Label6.Text = "Invalid Username and Password";
            }
        }
    }
}