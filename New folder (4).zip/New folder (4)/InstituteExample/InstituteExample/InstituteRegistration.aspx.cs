﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InstituteExample
{
    public partial class InstituteRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                List<string> list = new List<string>();
                list = CInstitute_BAL.mGetAllInstitute();
                DropDownList1.AppendDataBoundItems = true;
                foreach (string val in list)
                {
                    DropDownList1.Items.Add(val);
                }
                List<string> branchlist = new List<string>();
                branchlist = CInstitute_BAL.mGetAllCourse();
                DropDownList2.AppendDataBoundItems = true;
                foreach (string val in list)
                {
                    DropDownList2.Items.Add(val);
                }
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Label9.Text = "Student Added Suceesfully";
        }
    }
}